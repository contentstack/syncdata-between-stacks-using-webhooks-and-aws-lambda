/*
 * Module dependencies
 */

const axios = require("axios");
const async = require("async");

const {
  globalStackManagementToken,
  apiKeyStackA,
  stackAManagementToken,
  apiKeyStackB,
  stackBManagementToken,
  regionUrl,
  stackAPublishEnv,
  stackBPublishEnv,
} = process.env;

// Below function will get the entry from global stack which needs to be updated with child stacks

const fetchEntries = async (apiKeyGlobalStack, contentTypeUid, entryUid) => {
  let options = {
    method: "get",
    url: `${regionUrl}v3/content_types/${contentTypeUid}/entries/${entryUid}`,
    json: true,
    headers: {
      "content-Type": "application/json",
      authorization: globalStackManagementToken,
      api_key: apiKeyGlobalStack,
    },
  };

  let response = await axios(
    `${regionUrl}v3/content_types/${contentTypeUid}/entries/${entryUid}`,
    options
  );
  return Promise.resolve(response.data);
};

// update call for Stack A & B content-type entries

const updateChildStacks = async (
  entry,
  contentTypeUid,
  entryUidStackA,
  entryUidStackB
) => {
  return new Promise(async (resolve, reject) => {
    async.parallel(
      [
        (callback) => {
          axios({
              method: "put",
              url: `${regionUrl}v3/content_types/${contentTypeUid}/entries/${entryUidStackA}`,
              headers: {
                "Content-Type": "application/json",
                authorization: stackAManagementToken,
                api_key: apiKeyStackA,
              },
              data: {
                entry: entry,
              },
            })
            .then((result) => {
              callback(null, result);
            })
            .catch((err) => {
              console.log(err);
            });
        },
        (callback) => {
          axios({
              method: "put",
              url: `${regionUrl}v3/content_types/${contentTypeUid}/entries/${entryUidStackB}`,
              headers: {
                "Content-Type": "application/json",
                authorization: stackBManagementToken,
                api_key: apiKeyStackB,
              },
              data: {
                entry: entry,
              },
            })
            .then((result) => {
              callback(null, result);
            })
            .catch((err) => {
              console.log(err);
            });
        },
      ],
      (error, success) => {
        if (error) return next(error);
        if (success[0].status && success[1].status == 200) {
          resolve(success);
        }
      }
    );
  });
};

// publish call for stack A & B entries

const publishEntries = async (contentTypeUid, entryAUid, entryBUid) => {
  return new Promise(async (resolve, reject) => {
    async.parallel(
      [
        (callback) => {
          axios({
              method: "post",
              url: `${regionUrl}v3/content_types/${contentTypeUid}/entries/${entryAUid}/publish`,
              headers: {
                "Content-Type": "application/json",
                authorization: stackAManagementToken,
                api_key: apiKeyStackA,
              },
              data: {
                entry: {
                  environments: [stackAPublishEnv],
                },
              },
            })
            .then((result) => {
              callback(null, result);
            })
            .catch((err) => {
              console.log(err);
            });
        },
        (callback) => {
          axios({
              method: "post",
              url: `${regionUrl}v3/content_types/${contentTypeUid}/entries/${entryBUid}/publish`,
              headers: {
                "Content-Type": "application/json",
                authorization: stackBManagementToken,
                api_key: apiKeyStackB,
              },
              data: {
                entry: {
                  environments: [stackBPublishEnv],
                },
              },
            })
            .then((result) => {
              callback(null, result);
            })
            .catch((err) => {
              console.log(err);
            });
        },
      ],
      (error, success) => {
        if (error) return next(error);
        resolve(success);
      }
    );
  });
};

// get entry uid for stack A

const getChildStackAUid = async (contentTypeUid) => {
  let options = {
    method: "get",
    json: true,
    headers: {
      "content-Type": "application/json",
      authorization: stackAManagementToken,
      api_key: apiKeyStackA,
    },
  };

  let response = await axios(
    `${regionUrl}v3/content_types/${contentTypeUid}/entries`,
    options
  );
  return Promise.resolve(response.data.entries[0].uid);
};

// get entry uid for stack B

const getChildStackBUid = async (contentTypeUid) => {
  let options = {
    method: "get",
    json: true,
    headers: {
      "content-Type": "application/json",
      authorization: stackBManagementToken,
      api_key: apiKeyStackB,
    },
  };

  let response = await axios(
    `${regionUrl}v3/content_types/${contentTypeUid}/entries`,
    options
  );
  return Promise.resolve(response.data.entries[0].uid);
};

exports.handler = async (event) => {
  let body = JSON.parse(event.body);
  let entryUidA = await getChildStackAUid(body.data.content_type.uid);
  let entryUidB = await getChildStackBUid(body.data.content_type.uid);
  try {
    if (body.data.content_type.uid === event.headers.defaultEntryA) {
      let entryResponse = await fetchEntries(
        body.api_key,
        body.data.content_type.uid,
        body.data.entry.uid
      );
      await updateChildStacks({
          privacy_detail: entryResponse.entry.privacy_detail,
        },
        body.data.content_type.uid,
        entryUidA,
        entryUidB
      );
      await publishEntries(body.data.content_type.uid, entryUidA, entryUidB);
    }
    if (body.data.content_type.uid === event.headers.defaultEntryB) {
      let entryResponse = await fetchEntries(
        body.api_key,
        body.data.content_type.uid,
        body.data.entry.uid
      );
      await updateChildStacks({
          logo: {
            link: entryResponse.entry.logo.link,
          },
          url: entryResponse.entry.url,
          title: entryResponse.entry.title,
          navigation_section: {
            navigation_bar: entryResponse.entry.navigation_section.navigation_bar,
          },
        },
        body.data.content_type.uid,
        entryUidA,
        entryUidB
      );
      await publishEntries(body.data.content_type.uid, entryUidA, entryUidB);
    }
    if (body.data.content_type.uid === event.headers.defaultEntryC) {
      let entryResponse = await fetchEntries(
        body.api_key,
        body.data.content_type.uid,
        body.data.entry.uid
      );
      await updateChildStacks({
          title: entryResponse.entry.title,
          footer: entryResponse.entry.footer,
          cta: entryResponse.entry.cta,
        },
        body.data.content_type.uid,
        entryUidA,
        entryUidB
      );
      await publishEntries(body.data.content_type.uid, entryUidA, entryUidB);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: `Update Successful !!`,
      }),
    };
  } catch (e) {
    console.log(e);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: e.message,
      }),
    };
  }
};